//
//  InsiderGender.h
//  InsiderShop
//
//  Created by Insider on 25.06.2019.
//  Copyright © 2019 Insider. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger, InsiderGender) {
    InsiderGenderMale = 0,
    InsiderGenderFemale,
    InsiderGenderOther,
};
